package com.jaudiostream;

import java.nio.ByteBuffer;

/**
 * <p>
 * Static utilities used by JAudioStream
 *  
 * @author ollie
 *
 */
public class Utils {

	public static final String ack = "ackn";
	public static final String begin = "begn";
	public static final String clear = "cler";
	public static final String commit = "comt";
	public static final String connect = "cont";
	public static final String connected = "cond";
	public static final String disConnect = "dcon";
	public static final String disConnected = "dctd";
	public static final String error = "eror";
	public static final String hearbeat = "hrbt";
	public static final String pause = "paus";
	public static final String paused = "paud";
	public static final String request = "rqst";
	public static final String reset = "rset";
	public static final String resume = "rsum";
	public static final String stream = "strm";
		
	public static final int packetSize = 512;
	public static final int headerSize = 12;
	public static final int payloadSize = packetSize-headerSize;
	public static final int minBuf = 256000;
	public static final int fourK = 1024 *4;
	public static final int minPackets = Math.round((fourK*4)/payloadSize);
	public static final int maxBuf = 768000;
	public static final int windowSize = 5;
	public static final int timeoutSafetyNet = 20;
	public static final int heartbeatTimeout = 150;
	public static final int clientHeartbeatTimeout = 200;
	public static final int maxMissedHeartBeats = 5;
	public static final int nextHeartBeatSend = 50;
	public static final String requestResponseEndPoint = "/rrstream";
	public static final String slidingWindowEndPoint = "/slwindow";
	public static final String scheme = "as"; 
		
	/**
	 * Converts the given integer to a byte array.
	 * 
	 * @param value - The integer to convert.
	 * @return The resultant array.
	 */
	static final byte[] intToByteArray(int value) {
		return new byte[] {
				(byte)(value >>> 24),
				(byte)(value >>> 16),
				(byte)(value >>> 8),
				(byte)value};
	}

	/**
	 * Converts the given byte array to an integer.
	 * 
	 * @param b - The byte array to convert.
	 * @return The resultant integer.
	 */
	static final int byteArrayToInt(byte[] b) {
		return (b[0] << 24)
		+ ((b[1] & 0xFF) << 16)
		+ ((b[2] & 0xFF) << 8)
		+ (b[3] & 0xFF);
	}
	
	/**
	 * Builds a byte array containing JAudioStream packet header
	 * based on the supplied command and parameters.
	 * 
	 * @param cmd - The command that the header should contain.
	 * @param prms - The integer parameters for the command.
	 * @return The resultant byte array.
	 */
	public static final byte[] makeHeader(String cmd, int... prms) {
		byte[] res = new byte[4];
		System.arraycopy(cmd.getBytes(), 0, res, 0, cmd.getBytes().length);
		for (int i : prms) {
			byte[] prm = intToByteArray(i);
			byte[] newBuf = new byte[res.length+prm.length];
			System.arraycopy(res, 0, newBuf, 0, res.length);
			System.arraycopy(prm, 0, newBuf, res.length, prm.length);
			res = newBuf;
		}
		return res;
	}

	/**
	 * Parses an incoming byte array into a JAudioStream packet.
	 *  
	 * @param in - The incoming byte array.
	 * @return The resultant packet.
	 */
	public static Packet parseMsg(byte[] in) {
		byte[] cmd = new byte[4];
		System.arraycopy(in, 0, cmd, 0, 4);
		byte[] prm1 = new byte[4]; 
		System.arraycopy(in, 4, prm1, 0, 4);
		byte[] prm2 = new byte[4]; 
		System.arraycopy(in, 8, prm2, 0, 4);
		byte[] data = new byte[payloadSize];
		System.arraycopy(in, 12, data, 0, payloadSize);
		return new Packet(new String(cmd).trim(), byteArrayToInt(prm1), byteArrayToInt(prm2), data);
	}
	
	/**
	 * Parses an incoming byte buffer into a JAudioStream packet.
	 *  
	 * @param in - The incoming byte buffer.
	 * @return The resultant packet.
	 */
	public static Packet parseMsg(ByteBuffer in) {
		byte[] cmd = new byte[4];
		byte[] prm1 = new byte[4]; 
		in.get(cmd, 0, cmd.length);
		if (in.limit() >= 4) {
			in.get(prm1, 0, prm1.length);
		}
		if (in.limit() == 8) {
			return new Packet(new String(cmd).trim(), byteArrayToInt(prm1), null);
		}
		if (in.limit() <= 16) {
			byte[] msg = new byte[8];
			in.get(msg, 0, msg.length);
			return new Packet(new String(cmd).trim(), byteArrayToInt(prm1), new String(msg).trim());
		} else {
			byte[] prm2 = new byte[4]; 
			byte[] data = new byte[payloadSize];
			if (in.limit() > 8) {
				in.get(prm2, 0, prm2.length);
				if (in.limit() > 12) {
					in.get(data, 0, data.length);
				}
			}
			return new Packet(new String(cmd).trim(), byteArrayToInt(prm1), byteArrayToInt(prm2), data);
		}		
	}
}
