package com.jaudiostream;

public class Packet extends Message implements Comparable<Packet> {
	
	public Packet(String cmd, int prm1, int prm2, byte[] data) {
		super(cmd, prm1, prm2, data);
	}
	
	public Packet(String cmd, int prm1, String message) {
		super(cmd, prm1, message);
	}
	
	public int id() {
		return params[0];
	}
	
	public int next() {
		return params[1];
	}
	
	@Override
	public int hashCode() {
		return id();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o == null) {
			return false;
		} else if (o == this) {
			return true;
		} else if (o instanceof Packet && ((Packet)o).id() == id()) {
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return "Packet id ["+String.valueOf(id())+"] next ["+String.valueOf(next())+"]";
	}

	@Override
	public int compareTo(Packet o) {
		if (o.id() < id()) {
			return 1;
		} else if (o.id() == id()) {
			return 0;
		} else {
			return -1;
		}
	}
}
