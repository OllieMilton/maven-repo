package com.jaudiostream;

import static com.jaudiostream.Utils.intToByteArray;
import static com.jaudiostream.Utils.packetSize;

public class Message {

	protected byte[] data = new byte[0];
	protected int [] params = new int[]{-1,-1};
	protected String command = "";
	protected String message = "";
	
	public Message(String cmd) {
		command = cmd;
	}
	
	public Message(String cmd, int prm1) {
		command = cmd;
		params[0] = prm1;
	}
	
	public Message(String cmd, String message) {
		command = cmd;
		this.message = message;
	}
	
	public Message(String cmd, int prm1, String message) {
		command = cmd;
		params[0] = prm1;
		this.message = message;
	}
	
	public Message(String cmd, int prm1, int prm2, byte[] data) {
		command = cmd;
		params[0] = prm1;
		params[1] = prm2;
		this.data = data;
	}
			
	public String command() {
		return command;
	}
	
	public int[] params() {
		return params;
	}
	
	public byte[] data() {
		return data;
	}
	
	public String getMessage() {
		if (message != null && !message.equals("")) {
			return message;
		} else {
			return new String(data).trim();
		}
	}

	public byte[] asBytes() {
		byte[] result = new byte[packetSize];
		if (!message.equals("")) {
			System.arraycopy(message.getBytes(), 0, result, 12, message.getBytes().length);
		} else {		
			System.arraycopy(intToByteArray(params[1]), 0, result, 8, 4);
			System.arraycopy(data, 0, result, 12, data.length);
		}
		System.arraycopy(command.getBytes(), 0, result, 0, 4);
		System.arraycopy(intToByteArray(params[0]), 0, result, 4, 4);
		return result;
	}
}
