package com.jaudiostream;

/**
 * <p>
 * Signals that the JAudioStream connection has been lost for some reason.
 * 
 * @author ollie
 *
 */
public class JAudioStreamLostException extends RuntimeException {

	private static final long serialVersionUID = -4810311593917597539L;

	public JAudioStreamLostException() {
		super();
	}
	
	public JAudioStreamLostException(String msg) {
		super(msg);
	}
	
	public JAudioStreamLostException(Throwable t) {
		super(t);
	}
}
