package com.jaudiostream.client;

import java.io.IOException;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.Message;
import com.jaudiostream.Packet;
import com.jaudiostream.Utils;

import ollie.common.datastructure.ArrayByteBuffer;
import ollie.utils.state.StateTransitionListener;

public class FullyBufferdSlidingWindowClient extends JAudioStreamClient {

	private final static Log logger = LogFactory.getLog(FullyBufferdSlidingWindowClient.class);
	private SortedSet<Packet> packets;
	private int lastPacket;
	
	public FullyBufferdSlidingWindowClient() {
		this((newState, oldState) -> logger.info("Transitioning from ["+oldState+"] to ["+newState+"]"));
	}
	
	public FullyBufferdSlidingWindowClient(StateTransitionListener<State> stateListener) {
		super(stateListener);
		packets = new TreeSet<Packet>();
		inputStream = new FullyBufferdInputStream();
		lastPacket = -1;
	}
	
	/**
	 * Clears the client ready for the next transmission.
	 */
	@Override
	protected void clearClient() {
		logger.info("Clearing client");
		synchronized (inputStream) {
			packets.clear();
			inputStream.clearBuffer();
			state.reset();
			lastPacket = -1;
		}
	}

	/**
	 * Processes a stream command.
	 * 
	 * @param m - The incoming message.
	 * @throws IOException - If the connection has been lost.
	 */
	@Override
	protected void handleStreamCmd(Message m) throws IOException {
		Packet p = (Packet)m;
		packets.add(p);
		logTrace("Added packet ["+p.id()+"] to set.");
		if (packets.size() >= Utils.minPackets || commitReceived) {
			fill();
		}
		send(new Message(Utils.ack, p.id()));
	}

	private void fill() {
		if (checkBuffer()) {
			Iterator<Packet> itr = packets.iterator();
			logTrace("Building buffer with ["+packets.size()+"] packets");
			while (itr.hasNext()) {
				Packet pkt = itr.next();
				inputStream.addToBuffer(pkt.data());
				itr.remove();
			}
			inputStream.release();
		}
	}
	
	/**
	 * Checks the buffer to ensure there re no gap between the packets
	 * i.e. checks for lost packets.
	 * 
	 * @return True if there are no or an acceptable amount of lost packets.
	 */
	private boolean checkBuffer() {
		int misMatches = -1;
		int lp = lastPacket;
		for (Packet p : packets) {
			if ((lp > -1) && (p.id() - lp != 1)) {
				misMatches ++;
			}
			lp = p.id();
		}
		int pMisMatch = -1;
		if (misMatches > 0) {
			pMisMatch = (misMatches*100)/packets.size();
			logger.info("Buffer has ["+pMisMatch+"] percent mis matches.");
		}
		if (pMisMatch < 1) {
			// less than 1% are mis matches so go for it.
			// first update last packet with the id of the last packet
			lastPacket = lp;
			return true;
		}
		return false;
	}
	
	/**
	 * Gets the number of bytes received since the buffer was last cleared.
	 * 
	 * @return The number of bytes received.
	 */
	public long getBytesReceived() {
		synchronized (inputStream) {
			return inputStream.getBuffer() != null ? inputStream.getBuffer().size() : 0;
		}
	}

	private class FullyBufferdInputStream extends JAudioInputStream {

		FullyBufferdInputStream() {
			super(state);
		}
		
		void begin(int size) {
			// add an extra 4k to the buffer for error - this will get corrected once the data has been committed
			buffer = new ArrayByteBuffer(size+Utils.fourK);
			markPos = 0;
			readlimit = -1;
		}

		@Override
		void commit() {
			// The tail of a transmission is smaller than minPackets so no
			// further stream command will trigger a fill - drain any packets
			// still waiting in the sorted set and wake a blocked reader.
			fill();
			super.commit();
			release();
		}
	}

}
