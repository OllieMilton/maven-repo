package com.jaudiostream.client;

import java.io.IOException;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.Message;
import com.jaudiostream.Packet;
import com.jaudiostream.Utils;

import ollie.common.datastructure.CircularByteBuffer;
import ollie.utils.state.StateTransitionListener;

public class CircularBufferedSlidingWindowClient extends JAudioStreamClient {

	private final static Log logger = LogFactory.getLog(CircularBufferedSlidingWindowClient.class);
	private SortedSet<Packet> packets;
	private int lastPacket;
	private boolean paused = false;
	
	public CircularBufferedSlidingWindowClient() {
		this((newState, oldState) -> logger.info("Transitioning from ["+oldState+"] to ["+newState+"]"));
	}
	
	public CircularBufferedSlidingWindowClient(StateTransitionListener<State> stateListener) {
		super(stateListener);
		packets = new TreeSet<Packet>();
		inputStream = new CircularBufferInputStream();
		lastPacket = -1;
	}

	/**
	 * Clears the client ready for the next transmission.
	 */
	@Override
	protected void clearClient() {
		logger.info("Clearing client");
		synchronized (inputStream) {
			packets.clear();
			inputStream.clearBuffer();
			state.reset();
			lastPacket = -1;
		}
	}

	/**
	 * Processes a stream command.
	 * 
	 * @param m - The incoming message.
	 * @throws IOException - If the connection has been lost.
	 */
	@Override
	protected void handleStreamCmd(Message m) throws IOException {
		Packet p = (Packet) m;
		packets.add(p);
		logTrace("Added packet ["+p.id()+"] to set.");
		if (packets.size() >= Utils.minPackets) {
			if (fill()) {
				if (!paused) {
					logger.info("Sending pause.");
					send(new Message(Utils.pause));
					paused = true;
				}
			}
		}
		send(new Message(Utils.ack, p.id()));
	}
	
	private boolean fill() {
		boolean full = false;
		if (checkBuffer()) {
			Iterator<Packet> itr = packets.iterator();
			while (itr.hasNext()) {
				Packet pkt = itr.next();
				if (inputStream.addToBuffer(pkt.data())) {
					lastPacket = pkt.id();
					itr.remove();
				} else {
					full = true;
					break;
				}
			}
			inputStream.release();
		}
		return full;
	}
	
	/**
	 * Checks the buffer to ensure there re no gap between the packets
	 * i.e. checks for lost packets.
	 * 
	 * @return True if there are no or an acceptable amount of lost packets.
	 */
	private boolean checkBuffer() {
		int misMatches = -1;
		int lp = lastPacket;
		for (Packet p : packets) {
			if ((lp > -1) && (p.id() - lp != 1)) {
				misMatches ++;
			}
			lp = p.id();
		}
		int pMisMatch = -1;
		if (misMatches > 0) {
			pMisMatch = (misMatches*100)/packets.size();
			logger.info("Buffer has ["+pMisMatch+"] percent mis matches.");
		}
		if (pMisMatch < 1) {
			// less than 1% are mis matches so go for it.
			return true;
		}
		return false;
	}
	
	private void resume() {
		try {
			send(new Message(Utils.resume));
		} catch (IOException e) {
			logger.error("Error while sending resume command.");
		}
	}

	private class CircularBufferInputStream extends JAudioInputStream {

		final int uppperLimit = (int) (2 * Math.pow(1024, 2));
		final int lowerLimit = (int) (1 * Math.pow(1024, 2));
		
		CircularBufferInputStream() {
			super(state);
		}

		@Override
		void begin(int size) {
			buffer = new CircularByteBuffer(uppperLimit);
		}

		@Override
		void commit() {
			// The tail of a transmission is smaller than minPackets so no
			// further stream command will trigger a fill - drain any packets
			// still waiting in the sorted set and wake a blocked reader.
			fill();
			super.commit();
			release();
		}
		
		@Override
		void clearBuffer() {
			streamAvailable = false;
			markPos = 0;
			readlimit = -1;
		}
		
		@Override
		boolean addToBuffer(byte[] in) {
			if (buffer.freeSpace() > in.length) {
				buffer.put(in);
				return true;
			} else {
				return false;
			}
		}
		
		@Override
		synchronized void checkStreamAvailable(boolean doLog) {
			if (buffer != null) {
				if (doLog) {
					logDebug("Checking buffer size ["+buffer.size()+"] pos ["+buffer.pos()+"] length ["+buffer.length()+"]");
					logDebug("Attempting buffer fill");
				}
				fill();
				if (buffer.size() <= lowerLimit && paused) {
					resume();
					logger.info("Sending resume.");
					paused = false;
				} 
				if (doLog) {
					logDebug("Checking buffer size ["+buffer.size()+"] pos ["+buffer.pos()+"] length ["+buffer.length()+"]");
				}
				// buffer is not empty, or the transmission is complete and the
				// buffer drained in which case the read path must run so that
				// it can signal end of stream.
				if (buffer.size() > 0 || (commitReceived && buffer.size() == 0)) {
					streamAvailable = true;
				} else {
					streamAvailable = false;
				}
			} else {
				streamAvailable = false;
			}
		}
	}
}
