package com.jaudiostream.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CountDownLatch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.client.JAudioStreamClient.State;

import ollie.common.datastructure.ByteBuffer;
import ollie.utils.state.StateHolder;

abstract class JAudioInputStream extends InputStream {

	private final Log logger = LogFactory.getLog(getClass());
	private CountDownLatch latch = new CountDownLatch(0);
	private StateHolder<State> state;
	protected volatile boolean streamAvailable = false;
	protected ByteBuffer buffer;
	protected int markPos = 0;
	protected int readlimit = -1;
	
	JAudioInputStream(StateHolder<State> state) {
		this.state = state;
	}
	
	private void checkClosed() throws IOException {
		if (state.get() == State.SHUTDOWN) {
			throw new IOException("Stream closed");
		}
	}
	
	ByteBuffer getBuffer() {
		return buffer;
	}
	
	/**
	 * Sets the stream to available and releases any blocked threads. 
	 */
	void release() {
		latch.countDown();
		streamAvailable = true;
	}
	
	abstract void begin(int size);
	
	void commit() {
		buffer.commit();
	}
	
	/**
	 * Resets the current position to the given position.
	 * @param pos - the new postion.
	 */
	synchronized void seek(int pos) {
		buffer.seek(pos);
	}
	
	/**
	 * Gets the current read position
	 * @return
	 */
	synchronized int readPos() {
		return buffer.pos();
	}
	
	/* (non-Javadoc)
	 * @see java.io.InputStream#available()
	 */
	@Override
	public int available() throws IOException {
		checkClosed();
		checkStreamAvailable(true);
		maybeWait();
		synchronized (this) {
			return buffer.size();
		}
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#read()
	 */
	@Override
	public int read() throws IOException {
		// delegate to the ranged read so that the empty buffer and end of
		// stream cases are distinguished, and mask to meet the InputStream
		// contract of returning 0-255 - returning the signed byte directly
		// made any 0xFF data byte look like end of stream.
		byte[] b = new byte[1];
		int read = read(b, 0, 1);
		return read == -1 ? -1 : b[0] & 0xFF;
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#read(byte[])
	 */
	@Override
	public int read(byte[] b) throws IOException {
		return read(b, 0, b.length);
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		checkClosed();
		checkStreamAvailable(true);
		maybeWait();
		return readInt(b, off, len);
	}

	/**
	 * Internal synchronised read method for the {@code java.io.InputStream#read(byte[] b, int off, int len)} read method.
	 * 
	 * @param b - The buffer into which the data is read.
	 * @param off - The start offset in array b at which the data is written.
	 * @param len - The maximum number of bytes to read. 
	 * @return The number of bytes read.
	 */
	private synchronized int readInt(byte[] b, int off, int len) throws IOException {
		state.transition(State.BUSY);
		logTrace("Start read offset ["+off+"] length ["+len+"] readlimit ["+readlimit+"]");
		logDebug("Buffer size ["+buffer.size()+"], Pos ["+buffer.pos()+"], Offset ["+off+"].");
		int read = buffer.get(b, off, len); 
		if (read > -1) {
			logTrace("New pos ["+buffer.pos()+"], Buffer size ["+buffer.size()+"], Read ["+read+"].");
		} else {
			logDebug("Nothing to stream - returning -1");
			// nothing available so set streamAvailable to false so that we block on the next call to read.
			streamAvailable = false;
		}
		return read;
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#markSupported()
	 */
	@Override
	public boolean markSupported() {
		return true;
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#reset()
	 */
	@Override
	public void reset() throws IOException {
		checkClosed();
		checkStreamAvailable(true);
		maybeWait();
		logDebug("Reset");
		synchronized (this) {
			buffer.seek(markPos);
			logger.info("** reset pos = "+markPos+" **");
		}
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#mark(int)
	 */
	@Override
	public void mark(int readlimit) {
		try {
			checkClosed();
			checkStreamAvailable(true);
			maybeWait();
			logDebug("Mark readlimit ["+readlimit+"]");
			synchronized (this) {
				logger.info("** Mark read = "+readlimit+" pos = ");
				this.readlimit = readlimit;
				markPos = buffer.pos();
				logger.info("** Mark read = "+readlimit+" pos = "+markPos+" **");
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#close()
	 */
	@Override
	public void close() {
		// override and do nothing here as some Java Sound SPI implementations close the stream at the end of a file.
		logger.info("******************** Stream closed ********************");
	}

	/* (non-Javadoc)
	 * @see java.io.InputStream#skip(long)
	 */
	@Override
	public long skip(long n) throws IOException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Adds the given byte array to the buffer.
	 * 
	 * @param in - The byte array to add.
	 */
	boolean addToBuffer(byte[] in) {
		buffer.put(in);
		return true;
	}

	/**
	 * Clears the buffer and resets input stream.
	 */
	void clearBuffer() {
		streamAvailable = false;
		buffer = null;
		markPos = 0;
		readlimit = -1;
	}

	/**
	 * Checks whether there is any data available in the buffer and 
	 * sets the streamAvailable flag accordingly.
	 */
	synchronized void checkStreamAvailable(boolean doLog) {
		if (buffer != null) {
			if (doLog) {
				logDebug("Checking buffer size ["+buffer.size()+"] pos ["+buffer.pos()+"] length ["+buffer.length()+"]");
			}
			// buffer is not empty    pos has not reached current number or pos has reached the end
			if (buffer.size() > 0 && (buffer.pos() < buffer.size() || buffer.pos() >= buffer.length())) {
				streamAvailable = true;
			} else {
				streamAvailable = false;
			}
		} else {
			streamAvailable = false;
		}
	}

	void maybeWait() throws IOException {
		while (!streamAvailable && state.is(State.CLEAR, State.BUSY)) {
			logger.info("No data available so blocking...  " +(buffer != null ? "buffer size ["+buffer.size()+"] pos ["+buffer.pos()+"] length ["+buffer.length()+"]" : ""));
			try {
				latch = new CountDownLatch(1);
				latch.await();
				logger.info("Data now available");
			} catch (InterruptedException e) {
				throw new IOException(e);
			}
		}
	}
	
	protected void logTrace(String msg) {
		if (logger.isTraceEnabled()) {
			logger.trace(msg);
		}
	}

	protected void logDebug(String msg) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg);
		}
	}
	
}
