package com.jaudiostream.client;

import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.JAudioStreamLostException;
import com.jaudiostream.Message;
import com.jaudiostream.Utils;

import ollie.utils.state.StateHolder;
import ollie.utils.state.StateTransitionListener;

/**
 * <p>
 * {@code JAudioStreamClient} represents the client side of the JAudioStream connection.
 * Packets are received from the server, acknowledged, ordered and stored.
 * <p>
 * Streamed data can be read from the {@code InputStream} accessed via {@code getInputStream()}.
 * @see java.io.InputStream
 * 
 * @author ollie
 *
 */
public abstract class JAudioStreamClient {

	private DatagramSocket socket;
	private InetAddress serverHost;
	private int serverPort;
	private volatile boolean connected;
	private AtomicLong lastMessageReceived;
	private AtomicInteger missedHeartbeats;
	private Timer heartbeatTimer;
	private int expectedBytes; 
	protected StateHolder<State> state;
	protected JAudioInputStream inputStream;
	protected Log logger = LogFactory.getLog(getClass());
	protected boolean commitReceived;
	
	public enum State {
		CLEAR, SHUTDOWN, ERROR, BUSY, TRANSMISSION_COMPLETE;
		String msg;
	}
	
	public JAudioStreamClient(StateTransitionListener<State> stateListener) {		
		lastMessageReceived = new AtomicLong(0);
		missedHeartbeats = new AtomicInteger(0);
		state = new StateHolder<State>(stateListener, State.CLEAR, State.SHUTDOWN);
		connected = false;
	}
	
	/**
	 * Connects the JAudioStreamClient to the given host and port.
	 * 
	 * @param url - the streaming URL address.
	 * @throws ConnectException
	 * @throws URISyntaxException 
	 */
	public void connect(String address) throws ConnectException, URISyntaxException {
		try {
			socket = new DatagramSocket();
			URI uri = new URI(address);
			state.reset();
			new Thread(() -> receiveLoop()).start();
			serverHost = InetAddress.getByName(uri.getHost());
			serverPort = uri.getPort();
			Message m = new Message(Utils.connect, uri.toString());
			int i = 0;
			while (!connected) {
				send(m);
				if (state.get() == State.ERROR) {
					handleError();
					throw new ConnectException(state.get().msg);
				} else if (++i > 10) {
					handleError();
					throw new ConnectException("Cannot connect to streaming server.");
				}
				Thread.sleep(400);
			}
			heartbeatTimer = new Timer();
			heartbeatTimer.scheduleAtFixedRate(new HeartBeatChecker(), 1000, Utils.heartbeatTimeout);
		} catch (IOException | InterruptedException e) {
			handleError();
			throw new ConnectException(e.getMessage());
		}
	}

	/**
	 * Disconnects the client from the server.
	 */
	public void disconnect() {
		if (connected) {
			try {
				send(new Message(Utils.disConnect));
				while (connected) {
					Thread.sleep(50);
				}
			} catch (IOException | InterruptedException e) {
				logger.error("Error disconnecting.");
			}
		}
		if (heartbeatTimer != null) {
			heartbeatTimer.cancel();
		}
	}

	public void shutdown() {
		disconnect();
		synchronized (inputStream) {
			socket.close();
			state.transition(State.SHUTDOWN); 
		}
	}
	
	private void handleError() {
		disconnect();
		synchronized (inputStream) {
			socket.close();
			if (!state.is(State.SHUTDOWN)) {
				state.transition(State.ERROR);
			} 
		}
	}

	/**
	 * Gets the local port assigned to this JAudioStreamCLient by the JVM.
	 * 
	 * @return The local port.
	 */
	public int getLocalPort() {
		return socket.getLocalPort();
	}

	/**
	 * Gets the {@code InputStream} for where the streamed data should be read from.
	 * 
	 * @return The {@code InputStream}
	 */
	public InputStream getInputStream() {
		return inputStream;
	}

	/**
	 * Determines whether this client is connected.
	 * 
	 * @return True if connected.
	 */
	public boolean isConnected() {
		return connected;
	}

	/**
	 * Gets the number of bytes that are expected to be received in the current transmission.
	 * @return The expected number of bytes. 
	 */
	public long getExpectedBytes() {
		return expectedBytes;
	}

	/**
	 * Determines whether the buffer has been cleared since the last transmission.
	 * 
	 * @return True if the buffer has been cleared.
	 */
	public boolean isClear() {
		if (state.get() == State.SHUTDOWN) {
			throw new JAudioStreamLostException("Stream closed.");
		}
		// if state is transmission complete and previous state is clear the the transmission 
		// must have completed before the stream has been read so treat as if clear.
		logDebug("Testing clear - ["+state+"]");
		return state.get() == State.CLEAR || (state.get() == State.TRANSMISSION_COMPLETE && state.getPrevious() == State.CLEAR);
	}
		
	/**
	 * Blocks the caller until the stream is clear.
	 */
	public void awaitClear(long timeout, TimeUnit unit) throws TimeoutException {
		if (state.get() == State.SHUTDOWN) {
			throw new JAudioStreamLostException("Stream closed.");
		}
		state.waitForState((value) -> isClear(), timeout, unit);
	}

	/**
	 * Finds the given position in the buffer and resets the input stream to that point.
	 * @param pos - the position to seek.
	 */
	public void seek(int pos) {
		inputStream.seek(pos);
	}
	
	/**
	 * Gets the current read position
	 * @return
	 */
	public int readPos() {
		return inputStream.readPos();
	}

	protected void logTrace(String msg) {
		if (logger.isTraceEnabled()) {
			logger.trace(msg);
		}
	}

	protected void logDebug(String msg) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg);
		}
	}
	
	/**
	 * Sends the given message to the server.
	 * 
	 * @param msg - The message to send. 
	 * @throws IOException - If the connection has been lost.
	 */
	protected void send(Message msg) throws IOException {
		DatagramPacket resp = new DatagramPacket(msg.asBytes(), msg.asBytes().length, serverHost, serverPort);
		socket.send(resp);
	}
	
	private class HeartBeatChecker extends TimerTask {
		
		@Override
		public void run() {
			if (connected) {
				long time = System.currentTimeMillis();
				long timeout  = lastMessageReceived.get()+Utils.clientHeartbeatTimeout;
				if (time > timeout) {
					if (missedHeartbeats.get() > Utils.maxMissedHeartBeats) {
						logger.error("Timed out waiting for heartbeat.");
						connected = false;
						handleError();
					} else {
						int missed = missedHeartbeats.incrementAndGet();
						logTrace("Missed ["+missed+"] heartbeats.");
					}
				}
			}
		}
	}
	
	private void receiveLoop() {
		int c = 0;
		while (!state.is(State.ERROR, State.SHUTDOWN)) {
			try {
				byte[] in = new byte[Utils.packetSize];
				DatagramPacket dp = new DatagramPacket(in, in.length);
				logTrace("Waiting fot packet");
				socket.receive(dp);
				Message m = Utils.parseMsg(in);
				if (m != null) {
					lastMessageReceived.set(System.currentTimeMillis());
					// clear the missed heartbeats as we are using the receipt of any message to reset last message received.
					missedHeartbeats.set(0);
					logTrace("Got command "+m.command());
					if (Utils.hearbeat.equals(m.command())) {
						//logTrace("Received heartbeat.");
						send(new Message(Utils.hearbeat));
					} else if (Utils.error.equals(m.command())) {
						State error = State.ERROR;
						error.msg = "Received error from server - "+m.getMessage();
						logger.error(error.msg);
						state.transition(error);
					} else {
						synchronized (inputStream) {
							if (Utils.begin.equals(m.command())) {
								expectedBytes = Integer.valueOf(m.getMessage());
								logger.info("Beginning transmission with ["+expectedBytes+"] bytes.");
								inputStream.begin(expectedBytes);
								commitReceived = false;
							} else if (Utils.clear.equals(m.command())) {
								logger.info("Received clear command.");
								clearClient();
							} else if (Utils.commit.equals(m.command())) {
								logger.info("Received commit.");
								commitReceived = true;
								// only set to complete if still clear - do not overwrite busy!
								state.conditionalTransition(State.CLEAR, State.TRANSMISSION_COMPLETE);
								inputStream.commit();
							} else if (Utils.stream.equals(m.command())) {
								try {
									logTrace("Received stream command ["+(++c)+"] with id ["+m.params()[0]+"]");
									handleStreamCmd(m);
								} catch (Exception e) {
									logger.error("Error in stream command, sending error to server.", e);
									// set to an error state, we can now only process stream commands if we first receive a clear.
									state.transition(State.ERROR);
									send(new Message(Utils.error));
								}
							} else if (Utils.connected.equals(m.command())) {
								connected = true;
							} else if (Utils.disConnected.equals(m.command())) {
								connected = false;
							}
						}
					}
				} else {
					logger.error("Error reading from socket.");
					handleError();
				}			
			} catch (IOException e) {
				logger.error("Error reading from connection, terminating", e);
				handleError();
			}
		}
	}
	
	protected abstract void clearClient();
	
	protected abstract void handleStreamCmd(Message m) throws IOException;
}
