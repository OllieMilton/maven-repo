package com.jaudiostream;

import java.nio.ByteBuffer;

/**
 * <p>
 * Container class used by the server side code to reference a given
 * packet with a time out and details of when it was sent.
 *  
 * @author ollie
 *
 */
public class PacketRef {

	private final ByteBuffer data;
	private long timeout;
	private final int id;
	private int retry;
	private boolean acked;
	private final long sent;

	public PacketRef(ByteBuffer data, int id) {
		this.data = data;
		this.timeout = 0L;
		this.id = id;
		retry  = -1;
		acked = false;
		sent = System.currentTimeMillis();
	}

	public ByteBuffer getData() {
		return data;
	}

	public long getTimeOut() {
		return timeout;
	}

	public void setTimeOut(int timeOut) {
		this.timeout = System.currentTimeMillis()+timeOut;
		retry ++;
	}

	public int getId() {
		return id;
	}

	public int getRetry() {
		return retry;
	}

	public boolean acked() {
		return acked;
	}

	public void ack() {
		acked = true;
	}
	
	public long sent() {
		return sent;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		if (obj instanceof PacketRef && ((PacketRef)obj).getId() == id) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public String toString() {
		return "PacketRef-"+id+"-"+data.toString();
	}		
}
