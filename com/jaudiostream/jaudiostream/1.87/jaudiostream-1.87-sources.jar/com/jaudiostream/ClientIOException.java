package com.jaudiostream;

import java.io.IOException;

public class ClientIOException extends IOException {

	private static final long serialVersionUID = -8853580852701277702L;

}
