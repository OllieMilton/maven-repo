package com.jaudiostream.server;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

import com.jaudiostream.Message;
import com.jaudiostream.PacketRef;
import com.jaudiostream.Utils;

/**
 * <p>
 * {@code JAudioStream} represents the server side of the JAudioStream connection.
 * Data should be written to the output stream in order to stream it to the client. 
 * 
 * A semaphore is used to block writing to the output stream until an acknowledgement
 * has been received.
 * 
 * @author ollie
 *
 */
public class SlidingWindowStream extends JAudioStream {

	private Map<Integer, PacketRef> packets;
	private Semaphore sem;
	private List<PacketRef> awaitingAck;
	private int ackCount;
	private int roundTripSum;
	private AtomicInteger resendTimeout;
	private boolean paused;
		
	public SlidingWindowStream(JAudioStreamListener listener, DatagramChannel channel, SocketAddress address, String name) {
		super(listener, channel, address, name);
		packets = new ConcurrentHashMap<Integer, PacketRef>(Utils.windowSize);
		awaitingAck = new ArrayList<PacketRef>(Utils.windowSize);
		payloadSize = Utils.payloadSize;
		resendTimeout = new AtomicInteger(200);
		sem = new Semaphore(Utils.windowSize, true);
		ackCount = 0;
		roundTripSum = 0;
		paused = false;
		connected();
	}
			
	protected void handleIncoming(Message m) {
		if (Utils.ack.equals(m.command())) {
			PacketRef pr = packets.remove(m.params()[0]);
			if (pr != null) {
				int tripTime = (int) (System.currentTimeMillis()-pr.sent());
				logDebug("Packet ["+pr.getId()+"] took ["+tripTime+"] ms for round trip.");
				pr.ack();
				synchronized (lock) {
					roundTripSum += tripTime;
					ackCount ++;
					if (ackCount >= 5) {
						int timeout = ((roundTripSum/ackCount)+Utils.timeoutSafetyNet);
						logDebug("Setting timeout to ["+timeout+"]");
						resendTimeout.set(timeout);
						roundTripSum = 0;
						ackCount = 0;
					}
					int idx = awaitingAck.indexOf(pr);
					if (idx == 0) {
						boolean acked = true;
						while (acked) {
							if (sem.availablePermits() < Utils.windowSize) {
								sem.release();
							}
							awaitingAck.remove(0);
							if (!awaitingAck.isEmpty()) {
								acked = awaitingAck.get(0).acked();
							} else {
								acked = false;
							}
						}
					}
				}				
			} else {
				logDebug("Got null packet ref for id ["+m.params()[0]+"], probably already acknowledged.");
			}
		} else if (Utils.pause.equals(m.command())) {
			// acquire all permits from semaphore - we don't want to block this thread though!
			if (!paused) {
				new Thread(() -> {sem.acquireUninterruptibly(Utils.windowSize); logger.info("******  Paused **** ["+sem.availablePermits()+"] ****");}).start();
				paused = true;
			}
			try {
				send(new Message(Utils.paused));
			} catch (IOException e) {
				closeWithErrorCatch();
			}
		} else if (Utils.resume.equals(m.command())) {
			if (paused) {
				sem.release(Utils.windowSize);
				logger.info("**** Resuming transmission ****");
				paused = false;
			}
		}
	}

	protected void tick() {
		synchronized (lock) {
			if (!awaitingAck.isEmpty()) {
				for (PacketRef pr : awaitingAck) {
					if (System.currentTimeMillis() >= pr.getTimeOut()) {
						try {
							pr.getData().flip();
							logDebug("Resending ["+pr.getId()+"] retries ["+pr.getRetry()+"]");
							channel.send(pr.getData(), address);
							pr.setTimeOut(resendTimeout.get());
						} catch (IOException e) {
							logger.error("Error resending packet stopping resender ["+pr.getId()+"]", e);
							closeWithErrorCatch();
						}
					}
				}
			} else {
				heartBeater.doHeartBeat();
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see java.io.OutputStream#write(byte[])
	 */
	@Override
	public void write(byte[] b) throws IOException {
		if (b.length > payloadSize) {
			throw new IOException("Payload too large, got payload of size ["+b.length+"] client max ["+payloadSize+"]");
		}
		checkClientError();
		checkClosed();
		try {
			sem.acquire();
			synchronized (lock) {
				checkClientError();
				checkClosed();
				int id = getNextId();
				ByteBuffer bb = ByteBuffer.wrap(new byte[payloadSize+Utils.headerSize]);
				bb.put(Utils.makeHeader(Utils.stream, id, -1));
				bb.put(b);
				bb.flip();
				PacketRef p = new PacketRef(bb, id);
				packets.put(id, p);
				awaitingAck.add(p);
				logDebug("Sending packet ["+id+"]");
				channel.send(bb, address);
				p.setTimeOut(resendTimeout.get());
				logDebug("Awaiting ack");
			}
		} catch (InterruptedException e) {
			throw new IOException(e);
		}
	}

	@Override
	protected void doClear() {
		packets.clear();
		awaitingAck.clear();
		sem.release(Utils.windowSize);
	}

	@Override
	protected void doClose() {
		synchronized (lock) {
			awaitingAck.clear();
		}
		// make sure all permits have been released so that we release any (potentially) blocked thread.
		sem.release(Utils.windowSize);
		
	}
}
