package com.jaudiostream.server;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.concurrent.CountDownLatch;

import com.jaudiostream.Message;
import com.jaudiostream.Utils;

public class RequestResponseStream extends JAudioStream {

	private CountDownLatch latch;
		
	public RequestResponseStream(JAudioStreamListener listener, DatagramChannel channel, SocketAddress address, String name) {
		super(listener, channel, address, name);
		latch = new CountDownLatch(1);
		connected();
	}
	
	@Override
	protected void handleIncoming(Message m) {
		if (m.command().equals(Utils.request)) {
			payloadSize = m.params()[0];
			latch.countDown();
		} 
	}
	
	@Override
	public void begin(long transmissionLength) throws IOException {
		send(new Message(Utils.begin));
	}

	@Override
	protected void send(byte[] msg) throws IOException {
		if (msg.length < payloadSize) {
			byte[] bMsg = new byte[payloadSize];
			System.arraycopy(msg, 0, bMsg, 0, msg.length);
			super.send(bMsg);
		} else {
			super.send(msg);
		}
	}

	@Override
	public void write(byte[] b) throws IOException {
		if (b.length > payloadSize) {
			throw new IOException("Payload too large, got payload of size ["+b.length+"] client max ["+payloadSize+"]");
		}
		checkClientError();
		checkClosed();
		try {
			latch.await();
			ByteBuffer bb = ByteBuffer.wrap(b);
			bb.put(b);
			bb.flip();
			channel.send(bb, address);
			latch = new CountDownLatch(1);
		} catch (Exception e) {
			throw new IOException(e);
		}
	}

	@Override
	protected void doClear() {
			
	}

	@Override
	protected void doClose() {
			
	}
	
	@Override
	protected void tick() {
		heartBeater.doHeartBeat();
	}
	
}