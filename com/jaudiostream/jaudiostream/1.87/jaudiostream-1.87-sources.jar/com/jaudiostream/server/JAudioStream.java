package com.jaudiostream.server;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.ClientIOException;
import com.jaudiostream.JAudioStreamLostException;
import com.jaudiostream.Message;
import com.jaudiostream.Utils;

public abstract class JAudioStream extends OutputStream {
	
	protected final Log logger = LogFactory.getLog(getClass());
	private String name;
	private JAudioStreamListener listener;
	private int packetId;
	private volatile boolean closed;
	private volatile boolean clientError;
	private volatile boolean connected;
	private long lastMessageReceived;
	private Timer resendTimer;
	protected HeartBeater heartBeater;
	protected final DatagramChannel channel;
	protected final SocketAddress address;
	protected int payloadSize;
	protected Object lock;
	
	public JAudioStream(JAudioStreamListener listener, DatagramChannel channel, SocketAddress address, String name) {
		this.name = name;
		this.listener = listener;
		this.channel = channel;
		this.address = address;
		packetId = 0;
		closed = false;
		clientError = false;
		connected = false;
		lastMessageReceived = 0;
		heartBeater = new HeartBeater();
		lock = new Object();
		resendTimer = new Timer();
		resendTimer.scheduleAtFixedRate(new TimerTask() {
			
			@Override
			public void run() {
				tick();
			}
		}, 1000, 50);
	}

	/**
	 * Gets the name of the stream.
	 * @return The stream name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the payload size for the stream.
	 * @return The paylosd size.
	 */
	public int getPayloadSize() {
		return payloadSize;
	}

	/**
	 * Tells the client that it has received all data for a given transmission.
	 * @throws IOException if not connected.
	 */
	public void commit() throws IOException {
		send(new Message(Utils.commit));
	}
	
	/**
	 * Informs the client that a transmission is about to start and passes the given
	 * message to the client.
	 * @param transmissionLength - amount of data to send.
	 * @throws IOException if not connected.
	 */
	public void begin(long transmissionLength) throws IOException {
		send(new Message(Utils.begin, 0, String.valueOf(transmissionLength)));
	}
	
	/**
	 * Gets the client port number.
	 * 
	 * @return The client port number.
	 */
	public int getClientPort() {
		return ((InetSocketAddress)address).getPort();
	}
	
	/**
	 * Gets the host name at the client end of the connection.
	 * 
	 * @return The client host name.
	 */
	public String getClientHost() {
		return ((InetSocketAddress)address).getHostString();
	}
	
	/**
	 * Sends the connected message to the client
	 */
	protected void connected() {
		try {
			send(new Message(Utils.connected));
			connected = true;
		} catch (IOException e) {
			// this should never happen so just throw back an unchecked exception
			throw new JAudioStreamLostException(e);
		}
	}
	
	protected int getNextId() {
		return ++packetId;
	}

	protected void checkClosed() throws IOException {
		if (closed) {
			throw new IOException("Stream closed!");
		}
	}
	
	protected void checkClientError() throws ClientIOException {
		if (clientError) {
			throw new ClientIOException();
		}
	}
	
	protected void send(Message msg) throws IOException {
		checkClosed();
		synchronized (lock) {
			try {
				send(msg.asBytes());
			} catch (IOException e) {
				throw new JAudioStreamLostException(e);
			}
		}
	}

	protected void send(byte[] msg) throws IOException {
		checkClosed();
		synchronized (lock) {
			try {
				ByteBuffer bb = ByteBuffer.wrap(msg);
				channel.send(bb, address);
			} catch (IOException e) {
				throw new JAudioStreamLostException(e);
			}
		}
	}
	
	/**
	 * Handles incoming message from the client side.
	 * 
	 * @param m - The incoming message.
	 */
	final public void incoming(Message m) {
		logDebug("Got incomming message ["+m.command()+"]");
		lastMessageReceived = System.currentTimeMillis();
		heartBeater.received();
		if (Utils.error.equals(m.command())) {
			clientError = true;
		} else if (Utils.disConnect.equals(m.command())) {
			closeWithErrorCatch();
		} else { 
			handleIncoming(m);
		}
	}
	
	/**
	 * Closes the connection
	 * 
	 * @throws IOException 
	 */
	public void close() throws IOException {
		try {
			send(new Message(Utils.disConnected));
		} finally {
			closed = true;
			connected = false;
			resendTimer.cancel();
			doClose();
			listener.onDissconnected(this);
		}
	}
	
	protected void logDebug(String msg) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg);
		}
	}
	
	protected class HeartBeater {
		AtomicInteger sent = new AtomicInteger(0);
		AtomicLong resendTime = new AtomicLong(0L);
		
		void doHeartBeat() {
			if (connected && System.currentTimeMillis() - lastMessageReceived > Utils.heartbeatTimeout) {
				if (resendTime.get() == 0L || System.currentTimeMillis() > resendTime.get()+Utils.nextHeartBeatSend) {
					try {
						send((new Message(Utils.hearbeat).asBytes()));
						sent.addAndGet(1);
						resendTime.set(System.currentTimeMillis());
						logDebug("Sending heartbeat.");
					} catch (IOException e) {
						logger.error("Error sending heart beat", e);
						closeWithErrorCatch();
					}
				}
			}
			if (sent.get() > Utils.maxMissedHeartBeats) {
				logger.error("Missed ["+sent.get()+"] heartbeats, closing connection.");
				closeWithErrorCatch();
			}
		}
		
		void received() {
			logDebug("Received heartbeat response.");
			sent.set(0);
			resendTime.set(0L);
		}
	}
	
	protected void closeWithErrorCatch() {
		try {
			close();
		} catch (IOException e) {
			logger.error("Error closing connection.", e);
		}
	}
	
	/**
	 * Clears the client the remote buffer and prepares for a new transmission.
	 * @throws IOException if not connected.
	 */
	public void clear() throws IOException {
		synchronized (lock) {
			doClear();
			packetId = 0;
			clientError = false;
			send(new Message(Utils.clear));
		}
	}
	
	/* (non-Javadoc)
	 * @see java.io.OutputStream#write(int)
	 */
	@Override
	public void write(int b) throws IOException {
		throw new UnsupportedOperationException();
	}
	
	protected abstract void handleIncoming(Message m);
	
	protected abstract void doClear();
	
	protected abstract void doClose();
	
	protected abstract void tick();
}
