package com.jaudiostream.server;

interface JAudioStreamListener {

	void onDissconnected(JAudioStream stream);
}
