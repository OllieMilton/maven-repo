package com.jaudiostream.server;

/**
 * <p>
 * An interface for listening to events coming from the JAudioStreamService.
 * 
 * @author ollie
 *
 */
public interface JAudioStreamServiceListener {

	/**
	 * Indicates that the client has dissconnected.
	 * @param stream - the stream that disconnected.
	 */
	public void onDissconnected(JAudioStream stream);
	
	public void onStreamAdded(JAudioStream stream);
}
