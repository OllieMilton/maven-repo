package com.jaudiostream.server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jaudiostream.Message;
import com.jaudiostream.Utils;

/**
 * Server side service for monitoring a UDP channel and creating server streams.
 * Clients connect using a URL that takes the following form:
 * <p>	
 * 	as://192.168.56.1:8887/slwindow?d7621b7e-e3cc-494d-93eb-ef3e7934233f
 * <p>
 * where /slwindow is the server end point and can either be /slwindow or /rrstream depending on the type of client
 * and ?d7621b7e-e3cc-494d-93eb-ef3e7934233f is some arbitrary string that names the stream.   
 * 
 *  
 * @author Ollie
 * 
 */
public class JAudioStreamService implements JAudioStreamListener {

	private final Log logger = LogFactory.getLog(getClass());
	private volatile boolean terminated;
	private DatagramChannel channel;
	private int port;
	private Map<Integer, JAudioStream> streams;
	private Map<String, JAudioStream> streamsByName;
	private List<JAudioStreamServiceListener> listeners = new ArrayList<>();
		
	public void init() throws IOException {
		streams = new ConcurrentHashMap<>();
		streamsByName = new ConcurrentHashMap<>();
		channel = DatagramChannel.open();
		channel.socket().bind(new InetSocketAddress(port));
		channel.configureBlocking(true);
		new Thread(()->receive()).start();
	}

	void shutdown() throws IOException {
		terminated = true;
		channel.close();
		for (JAudioStream srv : streams.values()) {
			srv.close();
		}
	}

	public JAudioStream getStream(String name) {
		return streamsByName.get(name);
	}

	public void closeStream(String name) throws IOException {
		JAudioStream srv = streamsByName.remove(name);
		if (srv != null) {
			srv.close();
		}
	}

	private void receive() {

		while (!terminated) {
			try {
				ByteBuffer b = ByteBuffer.allocate(Utils.packetSize);
				SocketAddress src = channel.receive(b);
				if (src != null) {
					InetSocketAddress socAddr = ((InetSocketAddress)src);
					b.flip();
					Message m = Utils.parseMsg(b);
					if (Utils.connect.equals(m.command())) {
						URI uri = new URI(m.getMessage());
						if (!uri.getScheme().equals(Utils.scheme)) {
							sendError(src, "Bad URL ["+uri.toString()+"] scheme unknown.");
							// end point empty...
						} else if ((uri.getPath() == null || uri.getPath().equals("")) ||
								// or unknown
								(!uri.getPath().equals(Utils.slidingWindowEndPoint) && !uri.getPath().equals(Utils.requestResponseEndPoint))) {
							sendError(src, "Bad URL ["+uri.toString()+"] server endpoint unknown.");
						} else if (uri.getQuery() == null || uri.getQuery().equals("")) {
							sendError(src, "Bad URL ["+uri.toString()+"] no stream specified.");
						}
						synchronized (streams) {
							if (!streams.containsKey(socAddr.getPort())) {
								if (uri.getPath().equals(Utils.requestResponseEndPoint)) {
									logger.info("Registering RR streaming client ["+uri.getQuery()+"] on port ["+socAddr.getPort()+"]");
									RequestResponseStream stream = new RequestResponseStream(JAudioStreamService.this, channel, src, uri.getQuery());
									streams.put(socAddr.getPort(), stream);
									streamsByName.put(uri.getQuery(), stream);
									if (listeners != null) {
										for (JAudioStreamServiceListener listener : listeners) {
											listener.onStreamAdded(stream);
										}
									}
								} else if (uri.getPath().equals(Utils.slidingWindowEndPoint)) {
									logger.info("Registering sliding window streaming client ["+uri.getQuery()+"] on port ["+socAddr.getPort()+"]");
									SlidingWindowStream stream = new SlidingWindowStream(JAudioStreamService.this, channel, src, uri.getQuery());
									streams.put(socAddr.getPort(), stream);
									streamsByName.put(uri.getQuery(), stream);
									if (listeners != null) {
										for (JAudioStreamServiceListener listener : listeners) {
											listener.onStreamAdded(stream);
										}
									}
								}
							}
						}
					} else {
						JAudioStream js = streams.get(socAddr.getPort());
						if (js != null) {
							js.incoming(m);
						}
					}
				}
			} catch (Exception e) {
				logger.error("An error occurred in the packet distributor.", e);
			}
		}
	}
	
	private void sendError(SocketAddress address, String msg) throws IOException {
		ByteBuffer bb = ByteBuffer.wrap(new Message(Utils.error, msg).asBytes());
		channel.send(bb, address);
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	public void setListeners(List<JAudioStreamServiceListener> listeners) {
		this.listeners.addAll(listeners);
	}
	
	public void addListener(JAudioStreamServiceListener listener) {
		listeners.add(listener);
	}

	@Override
	public void onDissconnected(JAudioStream stream) {
		streams.remove(stream.getClientPort());		
		streamsByName.remove(stream.getName());
		for (JAudioStreamServiceListener listener : listeners) {
			listener.onDissconnected(stream);
		}
	}
	
}
